package com.fdmgroup.bankDesignProject;

public class SavingsAccount extends Account {

	private double interestRate;

	public void addInterest() {
		balance = balance + balance * (interestRate / 100);
		
	}

	public double withdraw(double amount) {
		double withdrawn;
		if (amount > balance) {
			withdrawn = 0;
		} else {
			withdrawn = super.withdraw(amount);
		}
		return amount;

	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double Rate) {
		this.interestRate = Rate;
	}

}
