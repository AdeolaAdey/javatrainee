package com.fdmgroup.bankDesignProject;

import java.util.List;

public abstract class Account{
	
	
//Attributes	
	private final long ACCOUNT_ID;
	private static long nextAccountId = 1000;
	protected double balance;
	
//Constructor
	
	public Account() {
		this.ACCOUNT_ID =+ nextAccountId;
		nextAccountId += 5;	
	}
	public double withdraw(double amount) {
		this.balance = this.balance-amount;
		return amount;
	}
	public void deposit(double amount) {
		this.balance = this.balance + amount;
	}
	public void correctBalance(double amount) {
		this.balance = amount;
	}
	//Getters and Setters
	public double getBalance() {
		return balance;
	}	
	public long getACCOUNT_ID() {
		return ACCOUNT_ID;
	}



	
	
}
