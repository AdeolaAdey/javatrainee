package com.fdmgroup.bankDesignProject;


public class Company extends Customer {
	
	protected String name;
	protected String address;

	public Company(String name, String address) {
		super(name, address);

	}

	public void chargeAllAccounts(double amount) {
		for (Account account : getAccounts()) {
			if (account instanceof CheckingAccount) {
				account.withdraw(amount);
			} else if (account instanceof SavingsAccount) {
				account.withdraw(2 * amount);

			}
		}

	}
}