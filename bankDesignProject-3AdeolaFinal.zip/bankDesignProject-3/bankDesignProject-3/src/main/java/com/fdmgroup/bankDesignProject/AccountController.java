package com.fdmgroup.bankDesignProject;

import java.util.ArrayList;
import java.util.List;

//ATTRIBUTES
public class AccountController {

	private List<Customer> customers;
	private List<Account> accounts;

//CONSTRUCTOR
	public Account createCustomer(String name, String address, String type) {
		if (type.equals("person")) {
			Person person = new Person(name, address);
			customers.add(person);
			return person;
		} else if (type.equals("company")) {
			Company company = new Company(name, address);
			customers.add(company);
			return company;
		} else {
			return null;
		}

	}

	public Account createAccount(Customer customer, String type) {
		if (type.equals("checking")) {
			CheckingAccount checkingA = new CheckingAccount();
			accounts.add(checkingA);
			customer.addAccount(checkingA);
			return checkingA;
		}
		if (type.equals("savings")) {
			SavingsAccount savingsA = new SavingsAccount();
			customer.addAccount(savingsA);
			accounts.add(savingsA);
			return savingsA;
		} else {

			return null;
		}

	}

	public void removeCustomer(Customer customer) {
		List<Account> customerAcc = new ArrayList<>();
		for (Account account : accounts) {
			if (customer.getAccounts().contains(account)) {
				customerAcc.add(account);
			}
		}
		for (Account account : customerAcc) {
			accounts.remove(account);
		}
		customers.remove(customer);
	}

	public void removeAccount(Account account) {
		accounts.remove(account);
		for (Customer customer : customers) {
			if (customer.getAccounts().contains(account)) {
				customer.removeAccount(account);
			}
		}
		customers.remove(account);
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

}
