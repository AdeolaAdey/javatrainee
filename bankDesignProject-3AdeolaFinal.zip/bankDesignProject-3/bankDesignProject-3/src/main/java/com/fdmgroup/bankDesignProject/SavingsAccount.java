package com.fdmgroup.bankDesignProject;

public class SavingsAccount extends Account {

	private double interestRate;

	public double addInterest() {
		double interestDue = balance * (interestRate / 100);
		return interestDue += balance;
	}

	public double withdraw(double amount) {
		double withdrawn;
		if (amount > balance) {
			withdrawn = 0;
		} else {
			withdrawn = super.withdraw(amount);
		}
		return withdrawn;

	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double Rate) {
		this.interestRate = Rate;
	}

}
